//
//  WebSocketClient.swift
//  LiveMeeting
//
//  Created by huhuegg on 2017/1/5.
//  Copyright © 2017年 egg. All rights reserved.
//

import UIKit

enum WebSocketClientStatus: Int {
    case Connected
    case Disconnected
    case Connecting
}

class WebSocketClient: NSObject {
    static var websocketClient = WebSocketClient()
    
    static var instance:WebSocketClient {
        return websocketClient
    }
    
    var ws:WebSocket!
    
    var reconnect = false
    var scTag = 0
    var monitorTimer: Timer?
    var heartTimer: Timer?
    var messageQueue: [String] = []

    
    override init() {
        super.init()
        ws = WebSocket("ws://192.168.97.197:9012/ws")
        ws.event.open = {
            //print("⚛️ event open")
            self.onOpen()
        }
        
        ws.event.close = { code,reason,clean in
            //print("⚛️ event close")
            self.onClose()
        }
        
        ws.event.error = { error in
            //print("⚛️ event error")
            self.onError(error: error)
        }
        
        ws.event.message = { message in
            //print("⚛️ event recv message")
            self.onRecv(msg: message as! String)
        }
        
        ws.event.pong = { _ in
            //print("⚛️ event pong message")
            self.onPong(msg: "")
        }
        
        createTimer()
    }
    
    deinit {
        switch ws.readyState {
        //连接尚未完成
        case .connecting:
            close()
            break
        //已连接
        case .open:
            close()
            break
        //关闭中
        case .closing:
            break
        //已关闭或未连接
        case .closed:
            break
        default:
            break
        }
        
    }
    
    func createTimer() {
        DispatchQueue.main.async {
//            if self.monitorTimer == nil {
//                self.monitorTimer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(WebSocketClient.reconnectServer), userInfo: nil, repeats: true)
//            }
//            if self.heartTimer == nil {
//                var heartBeatInterval = self.socketConfig.heartBeatInterval / 4
//                heartBeatInterval = heartBeatInterval > 5 ? heartBeatInterval:5
//                
//                self.heartTimer = Timer.scheduledTimer(timeInterval: heartBeatInterval, target: self, selector: #selector(WebSocketClient.sendHeartBeat), userInfo: nil, repeats: true)
//            }
        }
    }
    
    func open() {
        print("⚛️ 创建WebSocket连接, WebSocket readyState:\(ws.readyState)")
        if ws.readyState == .closed {
            print("⚛️ 执行创建连接操作")
            ws.open()
        } else {
            //print("⚛️ 忽略创建连接逻辑, WebSocket readyState is \(ws.readyState)")
        }
        
    }
    
    func close() {
        print("⚛️ 关闭WebSocket连接, readyState:\(ws.readyState)")
        if ws.readyState == .open || ws.readyState == .connecting {
            ws.close()
        } else {
            print("⚛️ 忽略关闭连接逻辑, WebSocket readyState != .open or .connecting")
        }
    }
    
    func reconnectServer() {
        if reconnect {
            if ws.readyState == .closed {
                open()
            }
        }
    }
    
    func changeReconnect(status:Bool) {
        self.reconnect = status
    }
    
    func send(msg:String,completed:(_ status:Bool)->()) {
        
        if ws.readyState == .open {
            ws.send(msg)
            completed(true)
            return
        } else {
            print("⚛️❌ 发送消息失败:\(msg)")
            completed(false)
            return
        }
    }
    
    func sendHeartBeat() {
        let msg = "heartbeat"
        if ws.readyState == .open {
            //print("⚛️💗 ping心跳消息:\(msg)")
            ws.ping(msg)
        } else {
            print("⚛️💔 无法发送心跳消息, ws.readState != .open")
        }
    }
    
    //MARK:- Block回调处理
    func onOpen() {
        print("⚛️ WebSocket连接成功")
//        if let u = loginUser {
//            if u.token == "0" {
//                if u.platform == "Guest" {
//                    if LoginUser.userDefaultSid == "0" {
//                        LoginRequest(tag: "").doRequest(accountSid: "0", platform: u.platform, platformParams: "")
//                    } else {
//                        LoginRequest(tag: "").doRequest(accountSid: LoginUser.userDefaultSid, platform: u.platform, platformParams: "")
//                    }
//                }
//            } else {
//                OnlineRequest(tag: "").request()
//            }
//        }
//        NotificationCenter.default.post(name: NSNotification.Name(rawValue: kNotificationWebSocketStateChanged), object: nil, userInfo: ["state" : WebSocketClientStatus.Connected.rawValue])
    }
    
    func onClose() {
        print("⚛️ WebSocket连接关闭")
//        NotificationCenter.default.post(name:NSNotification.Name(rawValue: kNotificationWebSocketStateChanged), object: nil, userInfo: ["state" : WebSocketClientStatus.Disconnected.rawValue])
    }
    
    func onError(error:Error) {
        print("⚛️ WebSocket onError:\(error)")
    }
    
    func onRecv(msg:String) {
        print("⚛️ 收到消息:\(msg)")
//        BaseSocketResponse.processMessage(jsonStr: msg)
    }
    
    func onPong(msg:String) {
        print("⚛️💗 pong心跳消息:\(msg)")
        ws.ping()
    }
}
